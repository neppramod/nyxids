/**
 * 
 */

/**
 * @author root
 *
 */
public class RuleOption {
	
	private GeneralOption generalOption;
	private PayloadOption payloadOption;
	private NonPayloadOption nonPayloadOption;
	
	
	
	
	//getters
		

	public GeneralOption getGeneralOption(){
		return generalOption;
	}

	public PayloadOption getPayloadOption(){
		return payloadOption;
	}


	public NonPayloadOption getNonPayloadOption(){
		return nonPayloadOption;
	}	
	
	
			
	//setters
	

	
	
	public void setGeneralOption(GeneralOption s){
		generalOption=s;
	}
	
	public void setPayloadOption(PayloadOption s){
		payloadOption=s;
	}
	
	public void setNonPayloadOption(NonPayloadOption s){
		nonPayloadOption=s;
	}
	


}
