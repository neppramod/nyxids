/**
 * 
 */

/**
 * @author root
 *
 */
public class Rules {
	
	private RuleHeader ruleHeader;
	private RuleOption ruleOption;
	
	
	
	//getters
		

	public RuleHeader getRuleHeader(){
		return ruleHeader;
	}

	public RuleOption getRuleOption(){
		return ruleOption;
	}


		
	
	
			
	//setters
	

	
	
	public void setRuleHeader(RuleHeader s){
		ruleHeader=s;
	}
	
	public void setRuleOption(RuleOption s){
		ruleOption=s;
	}
	
	
	


}
