/**
 * 
 */

/**
 * @author root
 *
 */
public class RuleHeader {
	
	private String protocols=null;
	private IpAddress ipAddress;
	private PortNumber portNumber;
	private String direction=null;
	
	
	
	//getters
	public String getProtocols(){
		return protocols;
	}
	

	public IpAddress getIpAddress(){
		return ipAddress;
	}

	public PortNumber getPortNumber(){
		return portNumber;
	}


	public String getDirection(){
		return direction;
	}
	
			
	//setters
	

	public void setProtocols(String s){
		protocols=s;
	}
	
	public void setIpAddress(IpAddress s){
		ipAddress=s;
	}
	
	public void setPortNumber(PortNumber s){
		portNumber=s;
	}
	
	
	public void setDirection(String s){
		direction=s;
	}

	

}
