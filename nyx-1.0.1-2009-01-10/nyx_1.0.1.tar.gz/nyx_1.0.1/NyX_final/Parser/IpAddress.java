/**
 * 
 */

/**
 * @author root
 *
 */
public class IpAddress {

	private String source=null;
	private String destination=null;
	
	
	
	//getters
	public String getSource(){
		return source;
	}
	
	public String getDestination(){
		return destination;
	}
	
			
	//setters
	

	public void setSource(String s){
		source=s;
	}
	
	public void setDestination(String s){
		destination=s;
	}
	
		

}
