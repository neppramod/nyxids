/**
 * 
 */

/**
 * @author root
 *
 */
public class GeneralOption {
	
	private String msg=null;
	private String reference=null;
	private String gid=null;
	private String sid=null;
	private String rev=null;
	private String classtype=null;
	private String priority=null;
	private String metadata=null;
	
	
	
	//getters
	public String getMsg(){
		return msg;
	}
	
	public String getReference(){
		return reference;
	}
	
	public String getGid(){
		return gid;
	}
	
	public String getSid(){
		return sid;
	}
	
	public String getRev(){
		return rev;
	}
	
	public String getClasstype(){
		return classtype;
	}
	
	public String getPriority(){
		return priority;
	}
	
	public String getMetadata(){
		return metadata;
	}
	
		
		
	//setters
	

	public void setMsg(String s){
		msg=s;
	}
	
	public void setReference(String s){
		reference=s;
	}
	
	public void setGid(String s){
		gid=s;
	}
	
	public void setSid(String s){
		sid=s;
	}
	
	public void setRev(String s){
		rev=s;
	}
	
	public void setClasstype(String s){
		classtype=s;
	}
	
	public void setPriority(String s){
		priority=s;
	}
	
	public void setMetadata(String s){
		metadata=s;
	}
	
		


}
