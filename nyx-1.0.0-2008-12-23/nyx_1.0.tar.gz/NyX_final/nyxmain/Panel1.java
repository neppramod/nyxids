package nyxmain;

import java.awt.*;
import javax.swing.*;


public class Panel1 extends JPanel{
	
	public void paintComponent(Graphics g){
		
		Graphics2D g2d =(Graphics2D)g;
		GradientPaint gradient=new GradientPaint(0,0,Color.black,450,450,Color.gray);
		
		g2d.setPaint(gradient);
		g2d.fillRect(0,0,this.getWidth(),this.getHeight());
	}

}
